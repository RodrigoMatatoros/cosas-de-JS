var ele=document.createElement('div');
ele.innerHTML='Dibujo de los nodos del DOM<p>(por tipo de nodo)</p>';
document.body.appendChild(ele);