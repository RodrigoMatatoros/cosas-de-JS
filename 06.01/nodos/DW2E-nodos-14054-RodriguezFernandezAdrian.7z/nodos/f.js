var arrNodos = [];
var nivel = -1;

function inicio() {

    var ele = document;

    nodos(ele);


    for (let nod of arrNodos) {
        dibujarNodo(nod.substring(0, nod.length - 1), nod.substring(nod.length - 1) * 30);
    }


}

function nodos(padre) {

    var hijos = padre.childNodes;
    nivel++;

    for (let hijo of hijos) {

        arrNodos.push(hijo.nodeName + " (" + tipoNodo(hijo) + ")" + nivel);
        //  console.log(hijo);
        var atributes = hijo.attributes;
        var data = hijo.data;

        if (atributes != undefined) {
            for (let att of atributes) {
                arrNodos.push(att.name + "=" + att.nodeValue + ";;");
            }
        }

        if (data != undefined) {

            arrNodos.push(data + "_ ");
        }

        nodos(hijo);
    }

    nivel--;


}

function tipoNodo(nodo) {
    var tipoNodoArr = ["", "Element", "Attr", "Text", "CDATASection", "EntityReference", "Entity", "ProcessingInstruction", "Comment", "Document", "DocumentType", "DocumentFragment", "Notation"];
    return tipoNodoArr[nodo.nodeType].substring(0, 3).toLocaleLowerCase();;
}

function dibujarNodo(inner, left) {
    var ele = document.createElement('div');
    document.body.appendChild(ele);
    ele.innerHTML = inner;
    ele.style.clear = "left";
    ele.style.marginLeft = left;
    ele.style.marginBottom = "5px";
    ele.style.border = "1px solid black";
    ele.style.width = "130px";
    ele.style.textAlign = "center";
    ele.style.color = "red";
    ele.style.float = "left";

    if (inner.substring(inner.length - 1) == ";") {
        ele.style.color = "green";
        ele.style.float = "left";
        ele.style.clear = "none";
        ele.style.marginLeft = "5px";
    }

    if (inner.substring(inner.length - 1) == "_") {
        ele.style.color = "grey";
        ele.style.float = "left";
        ele.style.clear = "none";
        ele.style.marginLeft = "5px";
        ele.style.width = "330px";
        ele.style.color = "blue";
    }
}
// .nodeType, .attributes, .childNodes